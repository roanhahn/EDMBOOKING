# Changelog

## 1.1.0
- 添加左右箭头显示方式，可鼠标移入轮播图才显示
- 优化鼠标移入移除事件，使用mouseenter(mouseleave)代替mouseover(mouseout)事件

## 1.0.0
- 实现图片简单轮播
